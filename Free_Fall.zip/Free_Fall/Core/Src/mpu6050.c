#include "mpu6050.h"

void MPU6050_Init(void) {
    uint8_t data;

    // 1) Uyku modundan çıkar
    data = 0x00;
    HAL_I2C_Mem_Write(&hi2c1, MPU_ADDR, PWR_MGMT_1, 1, &data, 1, HAL_MAX_DELAY);

    HAL_Delay(100);

    // 2) Ölçek ayarı: ±2g (varsayılan zaten)
    data = 0x00;
    HAL_I2C_Mem_Write(&hi2c1, MPU_ADDR, ACCEL_CONFIG, 1, &data, 1, HAL_MAX_DELAY);
}

void MPU6050_ReadAccel(int16_t* Ax, int16_t* Ay, int16_t* Az) {
    uint8_t buf[6];
    HAL_I2C_Mem_Read(&hi2c1, MPU_ADDR, ACCEL_XOUT_H, 1, buf, 6, HAL_MAX_DELAY);
    *Ax = (int16_t)(buf[0] << 8 | buf[1]);
    *Ay = (int16_t)(buf[2] << 8 | buf[3]);
    *Az = (int16_t)(buf[4] << 8 | buf[5]);
}
