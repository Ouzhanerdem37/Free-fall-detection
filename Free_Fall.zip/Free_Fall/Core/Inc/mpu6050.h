#ifndef MPU6050_H
#define MPU6050_H

#include "stm32f4xx_hal.h"

// CubeMX'in oluşturduğu I2C handle'ı extern olarak buraya alın
extern I2C_HandleTypeDef hi2c1;

// MPU6050 I2C adresi (SA0=0)
#define MPU_ADDR        (0x68 << 1)

// Kayıt adresleri
#define PWR_MGMT_1      0x6B
#define ACCEL_XOUT_H    0x3B
#define ACCEL_CONFIG    0x1C

// Fonksiyon prototipleri
void MPU6050_Init(void);
void MPU6050_ReadAccel(int16_t* Ax, int16_t* Ay, int16_t* Az);

#endif // MPU6050_H
